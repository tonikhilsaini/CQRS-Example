﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace GameStreaks.Common
{
   public interface IEmailService
    {
        void SendRegistrationSuccessEmail(string fullname, string email, string toAddress, string password);
        void SendPasswordResetMessage(string email, string body);
        void SendConfirmationMessage(string email, string body);
        void SendRegistrationConfirmationMail(string email, string body);
        void SendOrderInfoMail(string email, string subject, string body);
        void SendMail(string email, string subject, string body);
        Task SendMailBysendgrid(string email, string subject, string body);
    }
}
