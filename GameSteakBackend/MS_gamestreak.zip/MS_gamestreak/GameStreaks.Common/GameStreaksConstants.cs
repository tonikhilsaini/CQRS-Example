﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Common
{
    public class GameStreaksConstants
    {
        #region Generic Messages
        public const string SOMETHINGWENTWRONG = "Something went wrong";
        public const string ERROR = "An error occured";
        public const string ERROR_TRY_AGAIN = "Please try again";
        public const string SUCCESS = "Success";
        public const string SUCCESS_DELETE = "User successfully deleted";
        public const string NO_RECORD = "No record(s) found";
        public const string NO_MORE_RECORDS = "No more record(s) available";
        #endregion
        #region Login/SignUp
        public const string USER_REGISTER_SUCCESS = "Registered successfully";
        public const string INVALIDCREDENTIALS = "User Name or Password is invalid";
        public const string LOGGEDIN = "Login successfull";
        public const string CUSTOMERCREATED = "Customer created successfully";
        public const string LOGGEDUSER = "User logged in";
        public const string INVALIDUSER = "Unauthorized User.";
        public const string LOGOUTUSER = "Successfully Logged Out.";
        // public const string CONFIRMEMAILSENT = "Confirmation email has sent successfully";

        #endregion
        #region Email
        public const string EMAILIDREQUIRED = "Email Id is required.";
        public const string INVALIDEMAIL = "Email Id is Invalid.";
        public const string REGISTEREDEMAIL = "Email already registered.";
        public const string RECOVERYEMAILSENT = "Successfully sent the reset email";
        public const string EMAILDOESNOTEXIST = "Email does not exists";
        public const string REGISTEREMAIL = "Please register yourself";
        public const string EMAILEXISTINDB = "Email you have entered is already registered with us";
        public const string CONFIRMEMAILSENT = "Confirmation email sent successfully";
        public const string CONFIRMEMAIL_SUCCESS = "Email confirmed successfully";
        public const string EMAIL_ALREADY_CONFIRMED = "Email already confirmed";
        public const string EMAIL_NOTCONFIRMED = "Invalid username or password";
        public const string PASSWORD_RESET = "Password reset successfully";
        #endregion

        #region Game
        public const string GAMEALREADYEXIST = "Game Already Exist";
        public const string GAMESUCCESS = "Game Successfully Added";
        public const string GAMELISTSUCCESS = "Game List Successfully Loaded";
        #endregion
        public const string PROFILEINFO_UPDATED = "Profile updated successfully.";
        public const string INVALID_PASSWORD_ERROR = "Incorrect current password";
        public const string ADDRESS_ADD = "Address added successfully";

        #region video
        public const string VIDEOUPLOADSUCCESS = "Video successfully upload.";
        public const string VIDEONOTUPLOADED = "Video upload fail.";
        public const string VIDEOCANNOTEMPTY = "Please select a video.";
        #endregion


        #region Game Request
        public const string SENDREQUEST = "Send Request";
        public const string REQUESTSEND = "Request Sent";
        public const string GAMESTART = "Game Start";
        public const string GAMEREQUESTSEND = "Game Request Activated";
        public const string ALREADYGAMEREQUESTACTIVATE = "Already Game Request Activated";
        public const string GAMEREQUEST = "Activate";
        public const string ALREADYGAMEREQUESTSEND = "Already Game Request Sent";
        public const string USERGAMELISTREQUEST = "User Game List Request Successfully Loaded";
        #endregion

        #region League
        public const string GAMELIST = "Game List Successfully Loaded";
        public const string ADDEDLEAGUETYPE = "League Type Added";
        public const string LEAGUETYPELIST = "League Type List Request Successfully Loaded";
        public const string ADDLEAGUEFORMAT = "League Format Added";
        public const string ADDNEWLEAGUE = "New League Added Successfully";
        public const string LEAGUEFORMATLIST = "League Format List Successfully Loaded";
        #endregion

        #region
        public const string LeagueList = "League List Successfully Loaded";
        public const string ADDCONFIDENCEGAME = "Confidence Game Added";
        public const string UPDATECONFIDENCEGAME = "Confidence Game Updated";
        public const string CONFIDENCEGAMELIST = "Confidence Game List Successfully Loaded";
        public const string DELETECONFIDENCEGAME = "Confidence Game Deleted";
        #endregion
    }
    public static class GameStreakRoles
    {
        #region Roles
        public const string ADMIN = "SuperAdmin";
        public const string ENDUSER = "EndUser";
        #endregion
    }

    public static class HTTPStatusCode
    {
        public const int SUCCESSSTATUSCODE = 200;
        public const int NO_DATA_FOUND = 204;
        public const int ERRORSTATUSCODE = 203;
        public const int INTERNAL_SERVER_ERROR = 500;
        public const int BADREQUEST = 400;
        public const int NOTFOUND = 404;
        public const int NOTAUTHORIZED = 401;
    }

    public static class AppSettings
    {
        public const string ACCOUNTCONFIMATIONMAIL = "AccountUrl:ConfirmEmail";
        public const string RESETPASSWORD = "AccountUrl:ResetPassword";
        public const string CONFIMATIONMAILTEMPLATE = "\\wwwroot\\EmailTemplate\\EmailConfirmationTemplate.html";
        public const string LOGGINGBASELOGO = "Logging:Baselogo";
        public const string HEADER_BACKGROUND_COLOR = "HEADER_BACKGROUND_COLOR";
        public const string FOOTER_BACKGROUND_COLOR = "FOOTER_BACKGROUND_COLOR";
        public const string HEADERBACKGROUNDCOLOR = "#095a68";
        public const string FOOTERBACKROUNDCOLOR = "#095a68";
        public const string ENDUSEREMAILCONFIRMATIONTEMPLATE = "\\wwwroot\\EmailTemplate\\EndUserEmailConfirmationTemplate.html";
        public const string HEADERLOGO = "HEADER_LOGO";
        public const string HEADERLOGOPATH = "PATH";
        public const string VERIFICATIONLINK = "{VerificationLink}";
        public const string FORGOTEMAILTEMPLATE = "\\wwwroot\\EmailTemplate\\ForgetPasswordTemplate.html";
        public const string ENDUSERFORGOTEMAILTEMPLATE = "\\wwwroot\\EmailTemplate\\EndUserForgetPasswordTemplate.html";
        public const string GAMESTREAKSNAME = "{StoreName}";
        public const string APPNAME = "GameStreak";
        public const string JWTKEY = "JwtKey";
        public const string JWTISSUEROPTION = "JwtIssuerOptions:Issuer";
        public const string JWTISSUERAUDENCE = "JwtIssuerOptions:Audience";
        public const string EMAILCONFIRMSUCCESS = "\\wwwroot\\EmailTemplate\\EmailConfirmSuccess.html";
        public const string DEFAULCORSPOLICY = "DefaultCorsPolicyName:PolicyUrl";
        public const string videoRoot = "wwwroot\\Videos";



    }



}


