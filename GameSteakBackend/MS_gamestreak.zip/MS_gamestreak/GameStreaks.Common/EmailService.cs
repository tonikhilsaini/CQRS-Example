﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;

namespace GameStreaks.Common
{
 public  class EmailService : IEmailService
    {
         readonly IConfigurationRoot _configuration;
        private readonly IMessageSender _messageSender;
        public EmailService(IConfigurationRoot configuration, IMessageSender messageSender)
        {
            _configuration = configuration;
            _messageSender = messageSender;
        }
        /// <summary>
        /// method to configure the html and email for registration email
        /// </summary>
        /// <param name="fullname"></param>
        /// <param name="storename"></param>
        /// <param name="email"></param>
        /// <param name="toAddress"></param>
        public void SendRegistrationSuccessEmail(string fullname, string email, string toAddress, string password)
        {
            string body = "<html>password:'" + password + "'</html>";
            string _configFromAddress = _configuration.GetSection("Logging:FromAddress").Value;
            string _configCC_RegistrationEmail = _configuration.GetSection("Logging:CC_RegistrationEmail").Value;
            string _configBCC_RegistrationEmail = _configuration.GetSection("Logging:BCC_RegistrationEmail").Value;
            _messageSender.SendAsync(_configuration.GetSection("Logging:FromAddress").Value, toAddress, "Welcome to GameStreak Application", body, _configuration.GetSection("Logging:CC_RegistrationEmail").Value, _configuration.GetSection("Logging:BCC_RegistrationEmail").Value);
        }

        public void SendPasswordResetMessage(string email, string body)
        {
            SendEmailWithSendGrid(email, "", "Password reset confirmation", true, body, _configuration.GetSection("Logging:FromAddress").Value, "Game Streaks");
            //_messageSender.SendAsync(_configuration.GetSection("Logging:FromAddress").Value, email, "Password reset confirmation", body, _configuration.GetSection("Logging:CC_RegistrationEmail").Value, _configuration.GetSection("Logging:BCC_RegistrationEmail").Value);
        }
        public void SendConfirmationMessage(string email, string body)
        {
            SendEmailWithSendGrid(email, "", "Welcome to GameStreak Application", true, body, _configuration.GetSection("Logging:FromAddress").Value, "Game Streaks");
            // _messageSender.SendAsync(_configuration.GetSection("Logging:FromAddress").Value, email, "Welcome to GameStreak Application", body, _configuration.GetSection("Logging:CC_RegistrationEmail").Value, _configuration.GetSection("Logging:BCC_RegistrationEmail").Value);
        }

        public void SendRegistrationConfirmationMail(string email, string body)
        {
            SendEmailWithSendGrid(email, "", "GameStreak - Email Confirmation", true, body, _configuration.GetSection("Logging:FromAddress").Value, "Game Streaks");
           // _messageSender.SendAsync(_configuration.GetSection("Logging:FromAddress").Value, email, "GameStreak - Email Confirmation", body, _configuration.GetSection("Logging:CC_RegistrationEmail").Value, _configuration.GetSection("Logging:BCC_RegistrationEmail").Value);
        }
        public bool SendEmailWithSendGrid(string EmailSendTo, string Name, string Subject, bool IsHTML, string EmailBody, string EmailFrom, string CampaignName)
        {
            try
            {
                MailMessage objMailMessage = new MailMessage
                {
                    Subject = Subject
                };

                if (string.IsNullOrEmpty(EmailFrom))
                {
                    objMailMessage.From = new MailAddress(EmailFrom, !string.IsNullOrEmpty(CampaignName) ? CampaignName : "Game Streaks ");
                }
                else
                {
                    objMailMessage.From = new MailAddress(EmailFrom, !string.IsNullOrEmpty(CampaignName) ? CampaignName : "GameStreak - Email Confirmation");
                }
                //objMailMessage.From = new mailaddress("noreply-caseconnect@kp.org", !string.IsNullOrEmpty(CampaignName) ? CampaignName : "Kaiser Permanente Case Installation");
                //var Emailfrom = objMailMessage.From.Address;

                // To
                //objMailMessage.To.Add(new mailaddress("neeraj_12@yopmail.com", "Neeraj Sharma")); 
                objMailMessage.To.Add(new MailAddress(EmailSendTo, "GameStreak - Email Confirmation"));
                // From
                objMailMessage.From = new MailAddress(objMailMessage.From.ToString());

                string text = "text body";
                string html = @EmailBody;
                objMailMessage.AlternateViews.Add(AlternateView.CreateAlternateViewFromString(text, null, MediaTypeNames.Text.Plain));
                objMailMessage.AlternateViews.Add(AlternateView.CreateAlternateViewFromString(html, null, MediaTypeNames.Text.Html));

                // Init SmtpClient and send
                var smtpClient = GetSmtpClient();

                smtpClient.Send(objMailMessage);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private SmtpClient GetSmtpClient()
        {
            return new SmtpClient("smtp.sendgrid.net", Convert.ToInt32(587))
            {
                Credentials = GetNetworkCredential()
            };
        }
        private System.Net.NetworkCredential GetNetworkCredential()
        {
            return new System.Net.NetworkCredential("onebusiness", "4949Send2413!");
        }


        public Task SendMailBysendgrid(string email, string subject, string body)
        {
            throw new NotImplementedException();
        }

        public void SendOrderInfoMail(string email, string subject, string body)
        {
            throw new NotImplementedException();
        }

        public void SendMail(string email, string subject, string body)
        {
            throw new NotImplementedException();
        }
    }
}
