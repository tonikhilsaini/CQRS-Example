﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace GameStreaks.Domain.Entities
{
   public class League :BaseEntity
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public Guid Id { get; set; }
        [Required]
        public string LeagueName { get; set; }
        [Required]
        public Guid LeagueTypeId { get; set; }
        [Required]
        public Guid LeagueFormatId { get; set; }
        [Required]
        public string StartWeek { get; set; }
        public Guid GameType { get; set; }
        [Required]
        public string EntryFee { get; set; }
        [Required]
        public string CurrentEntrants { get; set; }
        [Required]
        public string MaxEntrants { get; set; }
        [Required]
        public string Prize { get; set; }
        [Required]
        public DateTime StartDateTime { get; set; }
        [Required]
        public DateTime EndDateTime { get; set; }
    }
}
