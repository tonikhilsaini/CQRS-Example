﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace GameStreaks.Domain.Entities
{
    public partial class GameRequest : BaseEntity
    {
        [Key]
        public int Id { get; set; }
        public string GameID { get; set; }

        public string UserId { get; set; }

        public bool GameRequestStatus { get; set; }
    }
}
