﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace GameStreaks.Domain.Entities
{
    public class Address : BaseEntity
    {
        public long AddressId { get; set; }
        [Required]
        public Guid UserId { get; set; }
        [Required]
        [DefaultValue(0)]
        public int? CountryId { get; set; }
        [DefaultValue(0)]
        [Required]
        public int? StateId { get; set; }
        [Required]
        public string City { get; set; }
        [Required]
        public string ZipCode { get; set; }
        [Required]
        public string AddressLine { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string LandMark { get; set; }
        [Required]
        public string PhoneNumber { get; set; }
        [Required]
        public string AddressType { get; set; }
    }
}
