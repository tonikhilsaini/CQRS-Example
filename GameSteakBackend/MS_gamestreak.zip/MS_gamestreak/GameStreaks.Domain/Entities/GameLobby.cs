﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace GameStreaks.Domain.Entities
{
  public class GameLobby
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(Order = 1)]
        public long Id { get; set; }
        [Required]
        public Guid GameId { get; set; }
        [Required]
        public string Sport { get; set; }
        [Required]
        public string Style { get; set; }
        [Required]
        public DateTime Time { get; set; }
        [Required]
        [Column(TypeName = "decimal(15, 4)")]
        public decimal? EntryFee { get; set; }
        [Required]
        public int CurrentEntrants { get; set; }
        [Required]
        public int MaxEntrants { get; set; }
        [Required]
        public string Prize { get; set; }
        [Required]
        public string GameTypeId { get; set; }
        
    }
}
