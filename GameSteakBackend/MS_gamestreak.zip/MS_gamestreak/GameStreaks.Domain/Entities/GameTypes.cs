﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace GameStreaks.Domain.Entities
{
    public class GameTypes
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string GameType { get; set; }
        [Required]
        public Guid GameTypeId {get;set;}
    }
}
