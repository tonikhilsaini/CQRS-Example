﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.AdminDashboard.Model
{
   public  class DashboardCartdata
    {
        public string GameType { get; set; }
        public string GameTypeId { get; set; }
        public int count { get; set; }

    }
}
