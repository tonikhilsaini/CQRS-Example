﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.AdminDashboard.Model
{
    public class DashboardBarChartData
    {
        public string monthName { get; set; }
        public int usersCount { get; set; }
    }
}
