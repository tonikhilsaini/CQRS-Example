﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.AdminDashboard.Model
{
    class PaiChartModel
    {
    }
}
