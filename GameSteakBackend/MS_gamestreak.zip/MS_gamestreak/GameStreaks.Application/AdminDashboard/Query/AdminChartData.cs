﻿using GameStreaks.Application.AdminDashboard.Model;
using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.AdminDashboard.Query
{
      public class AdminChartData: IRequest<ApiResponse>
      {
         public string UserId { get; set; }
      }
}
