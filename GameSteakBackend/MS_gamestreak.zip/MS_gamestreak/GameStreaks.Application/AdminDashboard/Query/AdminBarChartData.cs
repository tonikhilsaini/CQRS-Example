﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.AdminDashboard.Query
{
    public class AdminBarChartData : IRequest<ApiResponse>
    {
        public string UserId { get; set; }


    }
}
