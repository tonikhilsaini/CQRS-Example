﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Application.Infrastructure.Dashboard;
using GameStreaks.Common;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.AdminDashboard.Query
{
    public class AdminBarChartDataQuery : IRequestHandler<AdminBarChartData, ApiResponse>
    {
        private readonly IDashboardService _dashboardService;
        public AdminBarChartDataQuery(IDashboardService dashboardService)
        {
            _dashboardService = dashboardService;
        }
        #region Admin Bar Chart Data
        public async Task<ApiResponse> Handle(AdminBarChartData request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                response = _dashboardService.GetAdminBarChartData(request);
                response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                response.Message = GameStreaksConstants.SUCCESS;
            }
            catch (Exception ex)
            {
                response.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
                response.Message = ex.Message;
            }
            return response;
        }
        #endregion
    }
}
