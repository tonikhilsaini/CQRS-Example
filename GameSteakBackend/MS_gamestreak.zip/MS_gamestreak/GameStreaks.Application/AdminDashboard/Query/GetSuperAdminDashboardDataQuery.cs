﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Application.Infrastructure.Dashboard;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.AdminDashboard.Query
{
    public class GetSuperAdminDashboardDataQuery : IRequestHandler<GetSuperAdminDashboardData, ApiResponse>
    {
        private readonly IDashboardService _dashboardService;
        public GetSuperAdminDashboardDataQuery(IDashboardService dashboardService)
        {
            _dashboardService = dashboardService;
        }
        #region Get Admin Dashboard Data
        public async Task<ApiResponse> Handle(GetSuperAdminDashboardData request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                response = _dashboardService.GetSuperAdminDashboardInfo(request);
                response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                response.Message = GameStreaksConstants.SUCCESS;
            }
            catch (Exception ex)
            {
                response.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
                response.Message = ex.Message;
            }
            return response;
        }
        #endregion
    }
}
