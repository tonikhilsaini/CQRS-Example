﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.GameLobbys.Command
{
   public class GetGameLobby :IRequest<ApiResponse>
    {
        public Guid GameId { get; set; }
        public string Sport { get; set; }
        public string Style { get; set; }
        public DateTime Time { get; set; }
        public decimal? EntryFee { get; set; }
        public int CurrentEntrants { get; set; }
        public int MaxEntrants { get; set; }
        public string Prize { get; set; }

        public string GameRequestStatus { get; set; }
       public List<GameTypes> GameType { get; set; }


    }
}
