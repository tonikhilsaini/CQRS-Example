﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Domain.Entities;
using GameStreaks.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.GameLobbys.Command
{
    public class GetGameLobbyHandler : IRequestHandler<GetGameLobby, ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public GetGameLobbyHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }
        #region Get All Active Games 
        /// <summary>
        /// Get All Active Tournament Or Upcoming Tournament
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ApiResponse> Handle(GetGameLobby request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                var GameExit = (from gamelobby in _dbContext.tbl_League.Where(x => x.StartDateTime > DateTime.Now)
                                join gamerequest in _dbContext.tbl_GameRequest on gamelobby.Id.ToString() equals gamerequest.GameID into sendrequest
                                from gameRequest in sendrequest.DefaultIfEmpty()
                                select new GetGameLobby
                                {
                                    GameId = gamelobby.Id,
                                    Sport = gamelobby.LeagueName,
                                    //Style = gamelobby.Style,
                                    Time = gamelobby.StartDateTime,
                                    EntryFee = Convert.ToDecimal(gamelobby.EntryFee),
                                    CurrentEntrants = Convert.ToInt32(gamelobby.CurrentEntrants),
                                    MaxEntrants = Convert.ToInt32(gamelobby.MaxEntrants),
                                    Prize = gamelobby.Prize,
                                    GameRequestStatus = (gameRequest == null) ? GameStreaksConstants.SENDREQUEST : (gameRequest.GameRequestStatus == false) ? GameStreaksConstants.REQUESTSEND : GameStreaksConstants.GAMESTART
                                }).ToList();


                GameExit[0].GameType = _dbContext.tbl_GameType.Where(x => x.GameTypeId != null).Select(x => new GameTypes
                {
                    Id = x.Id,
                    GameType = x.GameType,
                    GameTypeId=x.GameTypeId
                }) .ToList();
                //Getting Tournament List
                if (GameExit != null)
                {
                    response.Data.ResponseData = GameExit;
                    response.Message = GameStreaksConstants.GAMELISTSUCCESS;
                    response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
                else
                {
                    response.Message = GameStreaksConstants.NO_RECORD;
                    response.StatusCode = HTTPStatusCode.NO_DATA_FOUND;
                }
            }
            catch (Exception ex)
            {
                response.Message = GameStreaksConstants.NO_RECORD;
                response.StatusCode = HTTPStatusCode.NO_DATA_FOUND;
            }
            return response;
        }
        #endregion
    }
}
