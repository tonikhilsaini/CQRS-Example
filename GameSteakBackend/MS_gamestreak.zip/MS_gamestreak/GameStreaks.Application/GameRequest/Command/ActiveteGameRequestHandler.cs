﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.GameRequest.Command
{
    public partial class ActiveteGameRequestHandler : IRequestHandler<ActivateGameRequest, ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public ActiveteGameRequestHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<ApiResponse> Handle(ActivateGameRequest request, CancellationToken cancellationToken)
        {
            ApiResponse apiResponse = new ApiResponse();
            try
            {
                var gameRequest = _dbContext.tbl_GameRequest.Where(obj => obj.Id == request.GameRequestID && obj.GameRequestStatus == false).FirstOrDefault();
                if (gameRequest != null)
                {
                    gameRequest.GameRequestStatus = true;
                    _dbContext.Entry(gameRequest).State = EntityState.Modified;
                    await _dbContext.SaveChangesAsync();
                    apiResponse.Message = GameStreaksConstants.GAMEREQUESTSEND;
                    apiResponse.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
                else
                {
                    apiResponse.Message = GameStreaksConstants.ALREADYGAMEREQUESTSEND;
                    apiResponse.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }

            }
            catch (Exception e)
            {
                apiResponse.Message = GameStreaksConstants.ERROR;
                apiResponse.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
            }
            return apiResponse;
        }
    }
}
