﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using GameStreaks.Domain.Entities;

namespace GameStreaks.Application.GameRequest.Command
{
    class GameRequestHandler : IRequestHandler<GameRequests, ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public GameRequestHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<ApiResponse> Handle(GameRequests request, CancellationToken cancellationToken)
        {
            ApiResponse apiResponse = new ApiResponse();
            try
            {
                var checkGameRequest = _dbContext.tbl_GameRequest.Where(obj => obj.GameID == request.GameID && obj.GameRequestStatus == false).FirstOrDefault();
                if (checkGameRequest == null)
                {
                    var gameRequest = new GameStreaks.Domain.Entities.GameRequest
                    {
                        GameID = request.GameID,
                        UserId = request.UserID
                    };
                    _dbContext.Add(gameRequest);
                    await _dbContext.SaveChangesAsync();
                    apiResponse.Message = GameStreaksConstants.GAMEREQUESTSEND;
                    apiResponse.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
                else
                {
                    apiResponse.Message = GameStreaksConstants.ALREADYGAMEREQUESTSEND;
                    apiResponse.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }

            }
            catch (Exception e)
            {
                apiResponse.Message = GameStreaksConstants.ERROR;
                apiResponse.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
            }
            return apiResponse;
        }
    }
}
