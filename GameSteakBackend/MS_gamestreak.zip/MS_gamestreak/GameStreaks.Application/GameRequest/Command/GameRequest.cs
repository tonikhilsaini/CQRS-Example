﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.GameRequest.Command
{
    public class GameRequests : IRequest<ApiResponse>
    {
        public string GameID { get; set; }

        public string UserID { get; set; }
    }

    public partial class ActivateGameRequest : IRequest<ApiResponse>
    {
        public int GameRequestID { get; set; }
    }
}
