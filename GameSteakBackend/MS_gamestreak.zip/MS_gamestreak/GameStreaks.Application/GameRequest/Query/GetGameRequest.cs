﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.GameRequest.Query
{
    public partial class GetGameRequest : IRequest<ApiResponse>
    {
        public int GameRequestID { get; set; }
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public string Email { get; set; }

        public string GameRequestStatus { get; set; }
    }

    
}
