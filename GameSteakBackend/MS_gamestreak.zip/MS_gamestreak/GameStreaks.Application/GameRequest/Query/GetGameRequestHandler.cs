﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;

namespace GameStreaks.Application.GameRequest.Query
{
    public class GetGameRequestHandler :IRequestHandler<GetGameRequest,ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public GetGameRequestHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<ApiResponse> Handle(GetGameRequest request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                var userDetails=(from gamerequest in _dbContext.tbl_GameRequest.Where(obj=>obj.GameRequestStatus==false)
                                 join userData in _dbContext.tbl_User on gamerequest.UserId equals userData.UserId
                                 select new GetGameRequest
                                 {
                                     GameRequestID = gamerequest.Id,
                                     UserName=userData.UserName,
                                     FirstName=userData.FirstName,
                                     LastName=userData.LastName,
                                     Email=userData.Email,
                                     GameRequestStatus = GameStreaksConstants.GAMEREQUEST
                                 }).ToList();
                if (userDetails != null)
                {
                    response.Data.ResponseData = userDetails;
                    response.Message = GameStreaksConstants.USERGAMELISTREQUEST;
                    response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
                else
                {
                    response.Message = GameStreaksConstants.NO_RECORD;
                    response.StatusCode = HTTPStatusCode.NO_DATA_FOUND;
                }
            }
            catch (Exception ex)
            {
                response.Message = GameStreaksConstants.NO_RECORD;
                response.StatusCode = HTTPStatusCode.NO_DATA_FOUND;
            }
            return response;
        }
    }
}
