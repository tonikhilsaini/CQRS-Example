﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Domain.Entities;
using GameStreaks.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.AddGame.Query
{
    public class AddGameTypesHandler : IRequestHandler<AddGameTypes, ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public AddGameTypesHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }
        #region Add Game Type in DB
        /// <summary>
        /// Adding New Game Type In DB
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async  Task<ApiResponse> Handle(AddGameTypes request, CancellationToken cancellationToken)
        {
            ApiResponse apiResponse = new ApiResponse();
            try
            {
                //Adding New Game Type
                var GameType = _dbContext.tbl_GameType.Where(x => x.GameType.ToLower() == request.GameType.ToLower()).FirstOrDefault();
                if (GameType == null)
                {
                    var GameTyp = new GameTypes();
                    GameTyp.GameType = request.GameType;
                    GameTyp.GameTypeId = Guid.NewGuid();
                    _dbContext.Add(GameTyp);
                    await _dbContext.SaveChangesAsync();
                    apiResponse.Message = GameStreaksConstants.GAMESUCCESS;
                    apiResponse.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
                //Adding New Game Type
                else
                {
                    apiResponse.Message = GameStreaksConstants.GAMEALREADYEXIST;    //game exist in table gametype
                    apiResponse.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
            }
            catch (Exception e)
            {
                apiResponse.Message = GameStreaksConstants.ERROR;
                apiResponse.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
            }
            return apiResponse;
        }
        #endregion
    }
}
