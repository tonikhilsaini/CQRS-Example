﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.AddGame.Query
{
    public class AddGameTypes : IRequest<ApiResponse>
    {
        public string GameType { get; set; }
        public Guid GameTypeId { get; set; }
    }
}
