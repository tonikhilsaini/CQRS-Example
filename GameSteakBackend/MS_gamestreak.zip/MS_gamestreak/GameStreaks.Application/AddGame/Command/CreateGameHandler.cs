﻿using AutoMapper;
using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Domain.Entities;
using GameStreaks.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.AddGame.Command
{
    public class CreateGameHandler : IRequestHandler<CreateGame, ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public CreateGameHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }
        #region Create Game Handler
        /// <summary>
        /// Creating New League Or Tournament In DB Based On Game Type
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ApiResponse> Handle(CreateGame request, CancellationToken cancellationToken)
        {
            ApiResponse apiResponse = new ApiResponse();
            try
            {
                //Adding New Game In DB
                var GameExit = _dbContext.tbl_GameLobby.Where(x => x.Time == request.Time).FirstOrDefault();
                if (GameExit == null)
                {
                    var GameInfo = new GameLobby();
                    GameInfo.Sport = request.Sport;
                    GameInfo.GameId = Guid.NewGuid();
                    GameInfo.Style = request.Style;
                    GameInfo.Time = request.Time;
                    GameInfo.EntryFee = request.EntryFee;
                    GameInfo.CurrentEntrants = request.CurrentEntrants;
                    GameInfo.MaxEntrants = request.MaxEntrants;
                    GameInfo.Prize = request.Prize;
                    GameInfo.GameTypeId = _dbContext.tbl_GameType.FirstOrDefault(x => x.GameType == request.GameType).GameTypeId.ToString();
                    _dbContext.Add(GameInfo);
                    await _dbContext.SaveChangesAsync();
                    //Adding New Game In DB
                    apiResponse.Message = GameStreaksConstants.GAMESUCCESS;
                    apiResponse.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
                else
                {
                    apiResponse.Message = GameStreaksConstants.GAMEALREADYEXIST;    //Tournament or league already exist
                    apiResponse.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }

            }
            catch (Exception e)
            {
                apiResponse.Message = GameStreaksConstants.ERROR;
                apiResponse.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
            }
            return apiResponse;

        }
        #endregion

    }
}
