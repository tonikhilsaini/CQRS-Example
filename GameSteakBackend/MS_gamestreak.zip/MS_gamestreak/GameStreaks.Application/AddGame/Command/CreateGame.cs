﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.AddGame.Command
{
   public class CreateGame : IRequest<ApiResponse>
    {
        public  Guid GameId { get; set; }
        public string Sport { get; set; }
        public string Style { get; set; }
        public DateTime Time { get; set; }
        public decimal? EntryFee { get; set; }
        public int CurrentEntrants { get; set; }
        public int MaxEntrants { get; set; }
        public string Prize { get; set; }
        public string GameType { get; set; }

    }
}
