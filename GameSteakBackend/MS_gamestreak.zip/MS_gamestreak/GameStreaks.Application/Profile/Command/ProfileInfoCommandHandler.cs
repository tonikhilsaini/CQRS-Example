﻿using AutoMapper;
using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Domain.Entities;
using GameStreaks.Persistence;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.Profile.Command
{
    public class ProfileInfoCommandHandler : IRequestHandler<ProfileInfoCommand, ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public readonly IMapper _imapper;
        readonly UserManager<ApplicationUser> _userManager;
        public ProfileInfoCommandHandler(GameStreaksContext _dbContext, UserManager<ApplicationUser> _userManager) //
        {
            this._dbContext = _dbContext;
           this._userManager = _userManager;
        }
        #region Update Profile Info
        /// <summary>
        /// Getting And Updating Profile Info
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ApiResponse> Handle(ProfileInfoCommand request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                string role = string.Empty;
                //Updating Profile Info
                var _userinfo = await _dbContext.tbl_User.FirstOrDefaultAsync(x => x.UserId ==request.UserId && x.IsDeleted == false);
                if (_userinfo != null)
                {
                    var user = await _userManager.FindByEmailAsync(request.Email);

                    if (user == null)
                    {
                        response.StatusCode = HTTPStatusCode.BADREQUEST;
                        response.Message = GameStreaksConstants.EMAILDOESNOTEXIST;
                        return response;
                    }

                    _userinfo.FirstName = request.FirstName;
                    _userinfo.LastName = request.LastName;
                    _userinfo.ProfileImage = request.profileImage;
                    _userinfo.IsActive = true;
                    _userinfo.ModifiedDate = DateTime.UtcNow;
                    _dbContext.Update(_userinfo);
                    await _dbContext.SaveChangesAsync();
                }
                //Updating Profile Info
                var roles = _userManager.GetRolesAsync(await _userManager.FindByEmailAsync(request.Email));
                role = roles.Result[0];
                response.Data.LoginResponseModel.ProfileImage = _userinfo.ProfileImage;
                response.Data.LoginResponseModel.FullName = _userinfo.FirstName + " " + _userinfo.LastName;
                response.Message = GameStreaksConstants.PROFILEINFO_UPDATED; ;
                response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
            }
            catch (Exception ex)
            {
                response.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
                response.Message = GameStreaksConstants.ERROR;
            }
            return response;
        }
        #endregion
    }
}
