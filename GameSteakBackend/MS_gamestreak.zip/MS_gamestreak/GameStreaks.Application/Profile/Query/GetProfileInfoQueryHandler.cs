﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Application.Profile.Model;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.Profile.Query
{
    public class GetProfileInfoQueryHandler : IRequestHandler<GetProfileInfoQuery, ApiResponse>
    {
        readonly GameStreaksContext _dbcontext;
        UserManager<ApplicationUser> _userManager;
        public GetProfileInfoQueryHandler(GameStreaksContext dbcontext, UserManager<ApplicationUser> userManager)
        {
           _dbcontext = dbcontext;
            _userManager = userManager;
        }
        #region Getting Profile Info
        /// <summary>
        /// Getting Profile Info
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ApiResponse> Handle(GetProfileInfoQuery request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                //Getting Profile Info
                var _info = await _dbcontext.tbl_User.Where(x => x.UserId == request.UserId && x.IsDeleted == false).Select(x => new ProfileInfoModel
                {
                    UserId = Guid.Parse(x.UserId),
                    FirstName = x.FirstName,
                    LastName = x.LastName,
                    UserName = x.UserName,
                    Email = x.Email,

                }).FirstOrDefaultAsync();
                //Getting Profile Info
                response.Data.ResponseData = _info;
                response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                response.Message = GameStreaksConstants.SUCCESS;
            }
            catch(Exception ex)
            {
                response.StatusCode = HTTPStatusCode.ERRORSTATUSCODE;
                response.Message = ex.Message;
            }

            return response;

        }
        #endregion
    }
}
