﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Domain.Entities;
using GameStreaks.Persistence;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.Logout.Command
{
    public class LogoutHandler : IRequestHandler<Logout, ApiResponse>
    {
        GameStreaksContext _dbContext;
        public LogoutHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }
        #region LogOut
        /// <summary>
        /// Logging Out User And Setting The Active Status To False
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ApiResponse> Handle(Logout request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                //Setting IsActive To False
                User activateUser = _dbContext.tbl_User.Where(x => x.UserId.ToString() == request.UserId).FirstOrDefault();
                activateUser.IsActive = false;
                _dbContext.Update(activateUser);
                await _dbContext.SaveChangesAsync();
                response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                response.Message = GameStreaksConstants.LOGOUTUSER;
                //Setting IsActive To False
            }
            catch (Exception ex)
            {
                response.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
                response.Message = ex.Message;
            }
            return response;
        }
        #endregion
    }
}
