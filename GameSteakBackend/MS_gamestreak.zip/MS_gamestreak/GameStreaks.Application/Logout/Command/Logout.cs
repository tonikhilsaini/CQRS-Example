﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.Logout.Command
{
    public class Logout : IRequest<ApiResponse>
    {
        public string UserId { get; set; }

    }
}
