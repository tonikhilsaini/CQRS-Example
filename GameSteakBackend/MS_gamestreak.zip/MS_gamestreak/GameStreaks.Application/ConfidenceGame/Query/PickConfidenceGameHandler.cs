﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.ConfidenceGame.Query
{
    public class PickConfidenceGameHandler : IRequestHandler<PickConfidenceGame, ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public PickConfidenceGameHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<ApiResponse> Handle(PickConfidenceGame request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                var pickConfidenceGameList = (from league in _dbContext.tbl_League.Where(obj => obj.IsActive)
                                   join confidenceGame in _dbContext.tbl_ConfidenceGame on league.Id equals confidenceGame.LeagueId
                                   where league.Id==new Guid(request.LeagueId)
                                   select new PickConfidenceGame
                                   {
                                       LeagueId = league.Id.ToString(),
                                       QuestionId= confidenceGame.Id.ToString(),
                                       QuestionName=confidenceGame.Question
                                   });
                if (pickConfidenceGameList != null)
                {
                    response.Data.ResponseData = pickConfidenceGameList;
                    response.Message = GameStreaksConstants.LeagueList;
                    response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
                else
                {
                    response.Message = GameStreaksConstants.NO_RECORD;
                    response.StatusCode = HTTPStatusCode.NO_DATA_FOUND;
                }
            }
            catch (Exception ex)
            {
                response.Message = GameStreaksConstants.ERROR;
                response.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
            }
            return response;
        }
    }
}