﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.ConfidenceGame.Query
{
    public class GetLeague : IRequest<ApiResponse>
    {
        public string LeagueId { get; set; }
        public string LeagueName { get; set; }
    }
}
