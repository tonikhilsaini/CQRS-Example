﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.ConfidenceGame.Query
{
    public class PickConfidenceGame : IRequest<ApiResponse>
    {
        public string LeagueId { get; set; }
        public string QuestionId { get; set; }
        public string QuestionName { get; set; }
    }

}
