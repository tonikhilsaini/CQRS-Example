﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.ConfidenceGame.Query
{
    public class GetConfidenceGameHandler : IRequestHandler<GetConfidenceGame, ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public GetConfidenceGameHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<ApiResponse> Handle(GetConfidenceGame request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                var confidenceGameDetails = (from confidenceGame in _dbContext.tbl_ConfidenceGame.Where(obj => obj.IsActive)
                                             join league in _dbContext.tbl_League on confidenceGame.LeagueId equals league.Id
                                             select new GetConfidenceGame
                                             {
                                                 LeagueName = league.LeagueName,
                                                 ConfidenceGameID = confidenceGame.Id.ToString(),
                                                 LeagueId = confidenceGame.LeagueId.ToString(),
                                                 question = confidenceGame.Question,
                                                 Option = confidenceGame.Option,
                                                 ConfidenceLevel = confidenceGame.ConfidenceLevel
                                             }).ToList();
                if (confidenceGameDetails != null)
                {
                    response.Data.ResponseData = confidenceGameDetails;
                    response.Message = GameStreaksConstants.CONFIDENCEGAMELIST;
                    response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
                else
                {
                    response.Message = GameStreaksConstants.NO_RECORD;
                    response.StatusCode = HTTPStatusCode.NO_DATA_FOUND;
                }
            }
            catch (Exception ex)
            {
                response.Message = GameStreaksConstants.ERROR;
                response.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
            }
            return response;
        }
    }
}
