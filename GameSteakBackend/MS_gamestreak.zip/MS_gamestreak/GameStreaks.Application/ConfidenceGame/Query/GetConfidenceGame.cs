﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.ConfidenceGame.Query
{
    public class GetConfidenceGame : IRequest<ApiResponse>
    {
        public string ConfidenceGameID { get; set; }
        public string LeagueId { get; set; }
        public string  LeagueName { get; set; }
        public string question { get; set; }
        public string Option { get; set; }
        public int ConfidenceLevel { get; set; }
    }
}
