﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.ConfidenceGame.Command
{
    public class DeleteConfidenceGame : IRequest<ApiResponse>
    {
        public string ConfidenceGameID { get; set; }
    }
}