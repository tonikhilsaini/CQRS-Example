﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.ConfidenceGame.Command
{
    public class DeleteConfidenceGameHandler : IRequestHandler<DeleteConfidenceGame, ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public DeleteConfidenceGameHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<ApiResponse> Handle(DeleteConfidenceGame request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                var confidenceGameDetails = _dbContext.tbl_ConfidenceGame.Where(obj => obj.IsActive && obj.Id == new Guid(request.ConfidenceGameID)).FirstOrDefault();
                
                if (confidenceGameDetails != null)
                {
                    confidenceGameDetails.IsActive = false;
                    confidenceGameDetails.IsDeleted = true;
                    confidenceGameDetails.DeletedDate = DateTime.UtcNow;
                    _dbContext.Entry(confidenceGameDetails).State = EntityState.Modified;
                    await _dbContext.SaveChangesAsync();
                    response.Message = GameStreaksConstants.DELETECONFIDENCEGAME;
                    response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
                else
                {
                    response.Message = GameStreaksConstants.ERROR;
                    response.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
                }
            }
            catch (Exception ex)
            {
                response.Message = GameStreaksConstants.ERROR;
                response.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
            }
            return response;
        }
    }
}