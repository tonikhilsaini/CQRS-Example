﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
namespace GameStreaks.Application.ConfidenceGame.Command
{
    public class CreateConfidenceGameHandler : IRequestHandler<CreateConfidenceGame, ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public CreateConfidenceGameHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<ApiResponse> Handle(CreateConfidenceGame request, CancellationToken cancellationToken)
        {
            ApiResponse apiResponse = new ApiResponse();
            try
            {
               
                if (request .confidenceGameID== null)
                {
                    var confidenceGame = new GameStreaks.Domain.Entities.ConfidenceGame
                    {
                        LeagueId = request.LeagueId,
                        Question = request.Question,
                        Option = request.Option,
                        ConfidenceLevel = Convert.ToInt32(request.ConfidenceLevel),
                        IsActive = true,
                        CreatedDate = DateTime.UtcNow,
                        IsDeleted = false
                    };
                    _dbContext.Add(confidenceGame);
                    apiResponse.Message = GameStreaksConstants.ADDCONFIDENCEGAME;
                }
                else
                {
                    var confidenceGame = _dbContext.tbl_ConfidenceGame.Where(obj => obj.IsActive && obj.Id == new Guid(request.confidenceGameID)).FirstOrDefault();
                    confidenceGame.LeagueId = request.LeagueId;
                    confidenceGame.Question = request.Question;
                    confidenceGame.Option = request.Option;
                    confidenceGame.ConfidenceLevel = request.ConfidenceLevel;
                    confidenceGame.ModifiedDate = DateTime.UtcNow;
                    _dbContext.Entry(confidenceGame).State = EntityState.Modified;
                    apiResponse.Message = GameStreaksConstants.UPDATECONFIDENCEGAME;
                }
                await _dbContext.SaveChangesAsync();
                apiResponse.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;

            }
            catch (Exception e)
            {
                apiResponse.Message = GameStreaksConstants.ERROR;
                apiResponse.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
            }
            return apiResponse;
        }
    }
}