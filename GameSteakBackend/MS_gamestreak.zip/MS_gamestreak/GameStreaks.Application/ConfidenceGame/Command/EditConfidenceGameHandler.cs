﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.ConfidenceGame.Command
{
    public class EditConfidenceGameHandler : IRequestHandler<EditConfidenceGame, ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public EditConfidenceGameHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<ApiResponse> Handle(EditConfidenceGame request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                var confidenceGameDetails = (from confidenceGame in _dbContext.tbl_ConfidenceGame.Where(obj => obj.IsActive && obj.Id==new Guid(request.ConfidenceGameID))
                                             join league in _dbContext.tbl_League on confidenceGame.LeagueId equals league.Id
                                             select new EditConfidenceGame
                                             {
                                                 ConfidenceGameID = confidenceGame.Id.ToString(),
                                                 LeagueId = confidenceGame.LeagueId.ToString(),
                                                 question = confidenceGame.Question,
                                                 Option = confidenceGame.Option,
                                                 ConfidenceLevel = confidenceGame.ConfidenceLevel
                                             }).FirstOrDefault();
                if (confidenceGameDetails != null)
                {
                    response.Data.ResponseData = confidenceGameDetails;
                    response.Message = GameStreaksConstants.CONFIDENCEGAMELIST;
                    response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
                else
                {
                    response.Message = GameStreaksConstants.NO_RECORD;
                    response.StatusCode = HTTPStatusCode.NO_DATA_FOUND;
                }
            }
            catch (Exception ex)
            {
                response.Message = GameStreaksConstants.ERROR;
                response.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
            }
            return response;
        }
    }
}
