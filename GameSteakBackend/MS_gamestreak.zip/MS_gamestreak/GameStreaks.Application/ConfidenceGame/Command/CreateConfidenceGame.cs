﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.ConfidenceGame.Command
{
    public class CreateConfidenceGame : IRequest<ApiResponse>
    {
        public string confidenceGameID { get; set; }

        public Guid LeagueId { get; set; }

        public string Question { get; set; }

        public string Option { get; set; }
        public int ConfidenceLevel { get; set; }

    }
}