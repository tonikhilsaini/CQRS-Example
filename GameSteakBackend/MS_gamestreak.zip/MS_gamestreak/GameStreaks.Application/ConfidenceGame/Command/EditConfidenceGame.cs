﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.ConfidenceGame.Command
{
   public class EditConfidenceGame : IRequest<ApiResponse>
    {
        public string ConfidenceGameID { get; set; }
        public string LeagueId { get; set; }
        public string question { get; set; }
        public string Option { get; set; }
        public int ConfidenceLevel { get; set; }
    }
}

