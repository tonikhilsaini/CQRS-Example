﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Domain.Entities;
using GameStreaks.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.AdminData.DeleteUser
{
    public class DeleteUserQuery : IRequestHandler<DeleteUser, ApiResponse>
    {
        readonly GameStreaksContext _dbContext;
        public DeleteUserQuery(GameStreaksContext dbcontext)
        {
            _dbContext = dbcontext;
        }
        #region Deleting User
        /// <summary>
        /// Setting the IsDeleted Column In Users_Table To True
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ApiResponse> Handle(DeleteUser request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                //For Deleting User
                User userDetails = new User();
                var userDelete = _dbContext.tbl_User.Where(x => x.UserId.ToString() == request.UserId).FirstOrDefault();
                userDelete.IsDeleted = true;
                await _dbContext.SaveChangesAsync();
                response.Message = GameStreaksConstants.SUCCESS_DELETE;
                response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                //For Deleting User
            }
            catch (Exception ex)
            {
                response.Message = GameStreaksConstants.SOMETHINGWENTWRONG;
                response.StatusCode = HTTPStatusCode.BADREQUEST;
            }
            return response;
        }
        #endregion
    }
}
