﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.AdminData.ActiveUsersList.Query
{
    public class GetActiveUsersList : IRequest<ApiResponse>
    {
        public string UserId { get; set; }

    }
}
