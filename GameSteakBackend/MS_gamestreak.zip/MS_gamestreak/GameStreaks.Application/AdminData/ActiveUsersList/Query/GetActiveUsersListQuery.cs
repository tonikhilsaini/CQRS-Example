﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Domain.Entities;
using GameStreaks.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.AdminData.ActiveUsersList.Query
{
    public class GetActiveUsersListQuery : IRequestHandler<GetActiveUsersList, ApiResponse>
    {
        readonly GameStreaksContext _dbcontext;
        public GetActiveUsersListQuery(GameStreaksContext dbcontext)
        {
            _dbcontext = dbcontext;
        }
        #region Getting Logged In Users List
        /// <summary>
        /// Getting All Logged In Users At Current Time
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ApiResponse> Handle(GetActiveUsersList request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                //Taking All Logged In Users
                var userDetails = _dbcontext.tbl_User.Where(x => x.UserId.ToString() != request.UserId && x.IsDeleted == false && x.IsActive==true).Select(x => new User
                {
                    UserName = x.UserName,
                    Email = x.Email,
                    FirstName = x.FirstName,
                    LastName = x.LastName,
                    UserId = x.UserId
                }).ToList();
                //Taking All Logged In Users
                if (userDetails != null)
                {
                    response.Data.ResponseData = userDetails;
                    response.Message = GameStreaksConstants.SUCCESS;
                    response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
                else
                {
                    response.Message = GameStreaksConstants.NO_RECORD;
                    response.StatusCode = HTTPStatusCode.NO_DATA_FOUND;
                }
            }
            catch (Exception ex)
            {
                response.Message = GameStreaksConstants.SOMETHINGWENTWRONG;
                response.StatusCode = HTTPStatusCode.BADREQUEST;
            }
            return response;
        }
        #endregion

    }
}
