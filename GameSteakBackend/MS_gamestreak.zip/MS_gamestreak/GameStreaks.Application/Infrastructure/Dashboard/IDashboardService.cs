﻿using GameStreaks.Application.AdminDashboard.Query;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.Infrastructure.Dashboard
{
   public interface IDashboardService
    {
        ApiResponse GetSuperAdminDashboardInfo(GetSuperAdminDashboardData request);
        ApiResponse GetAdminChartData(AdminChartData request);
        ApiResponse GetAdminBarChartData(AdminBarChartData request);
    }
}
