﻿using GameStreaks.Application.AdminDashboard.Model;
using GameStreaks.Application.AdminDashboard.Query;
using GameStreaks.Common;
using GameStreaks.Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using GameStreaks.Domain.Entities;

using System.Text;
using System.Globalization;

namespace GameStreaks.Application.Infrastructure.Dashboard
{
    public class DashboardService : IDashboardService
    {
        GameStreaksContext _dbContext;
        public DashboardService(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }
        #region Admin Pie Chart Data
        /// <summary>
        /// Get Data for Pie Chart In Admin Dashboard
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public ApiResponse GetAdminChartData(AdminChartData request)
        {
            ApiResponse response = new ApiResponse();
            List<DashboardCartdata> chartdata = new List<DashboardCartdata>();
            try
            {
                //Get Pie Chart Data
                var res = (from gt in _dbContext.tbl_GameType
                           join gl in _dbContext.tbl_GameLobby on gt.GameTypeId.ToString() equals gl.GameTypeId
                           select new
                           {
                               GameId=gt.GameTypeId,
                               GameName=gt.GameType,
                           }).ToList();

                var result = res.Select(o => o.GameId).Distinct().ToList();
                foreach (var item in result)
                {
                    DashboardCartdata chart = new DashboardCartdata();
                    chart.count = res.Where(x => x.GameId == item).AsQueryable().Count();
                    chart.GameType = res.Where(x => x.GameId == item).FirstOrDefault().GameName;

                    chartdata.Add(chart);
                }
                response.Data.ResponseData = chartdata;
                response.Message = GameStreaksConstants.SUCCESS;
                response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                //Get Pie Chart Data
            }
            catch (Exception ex)
            {
                response.Message = GameStreaksConstants.SOMETHINGWENTWRONG;
                response.StatusCode = HTTPStatusCode.BADREQUEST;
            }
            return response;
        }
        #endregion

        #region Get Admin Dashboard Data
        /// <summary>
        /// Get Total Users, Total Active Users, Total League In Admin Dashboard 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public ApiResponse GetSuperAdminDashboardInfo(GetSuperAdminDashboardData request)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                response.Data.TotalUser = _dbContext.tbl_User.Where(x => x.UserId != null && x.UserId.ToString()!=request.UserId).AsQueryable().Count();
                response.Data.TotalActiveUser = _dbContext.tbl_User.Where(x => x.IsActive == true && x.UserId.ToString() != request.UserId).AsQueryable().Count();
                response.Data.TotalLeague = _dbContext.tbl_GameLobby.Where(x => x.GameId != null).AsQueryable().Count();
                response.Message = GameStreaksConstants.SUCCESS;
                response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
            }
            catch (Exception ex)
            {
                response.Message = GameStreaksConstants.SOMETHINGWENTWRONG;
                response.StatusCode = HTTPStatusCode.BADREQUEST;
            }
            return response;
        }
        #endregion

        #region Admin Bar Chart Data
        /// <summary>
        /// Get Bar Chart Data For Admin Dashboard
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public ApiResponse GetAdminBarChartData(AdminBarChartData request)
        {
            ApiResponse response = new ApiResponse();
            List<DashboardBarChartData> barChartData = new List<DashboardBarChartData>();
            try
            {
                var currentDateTime = DateTime.Now;
                var lastSixMonth = DateTime.Now.AddMonths(-6);
                var userData = _dbContext.tbl_User.Where(x => x.CreatedDate < currentDateTime && x.CreatedDate > lastSixMonth && x.UserId.ToString() != request.UserId).Select(x => new User
                {
                    UserId = x.UserId,
                    CreatedDate=x.CreatedDate
                }).ToList();
                if(userData==null)
                {
                    response.Message = GameStreaksConstants.NO_RECORD;
                    response.StatusCode = HTTPStatusCode.NO_DATA_FOUND;
                }
                else
                {
                    //Taking Month Name And No. Of Users Added In That Month
                    var result = userData.Select(o => o.CreatedDate.Month).Distinct().ToList();
                    foreach (var data in result)
                    {
                        DashboardBarChartData barChart = new DashboardBarChartData();
                        var monthName = CultureInfo.CurrentCulture.DateTimeFormat.GetAbbreviatedMonthName(data);
                        barChart.monthName = monthName;
                        barChart.usersCount = userData.Where(x => x.CreatedDate.Month== data).AsQueryable().Count();
                        barChartData.Add(barChart);
                    }
                    response.Data.ResponseData = barChartData;
                    response.Message = GameStreaksConstants.SUCCESS;
                    response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                    //Taking Month Name And No. Of Users Added In That Month
                }
            }
            catch(Exception ex)
            {
                response.Message = GameStreaksConstants.SOMETHINGWENTWRONG;
                response.StatusCode = HTTPStatusCode.BADREQUEST;
            }
            return response;
        }
        #endregion
    }
}
