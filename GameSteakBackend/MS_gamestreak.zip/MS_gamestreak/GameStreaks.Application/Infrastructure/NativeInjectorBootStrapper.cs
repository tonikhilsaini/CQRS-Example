﻿using GameStreaks.Application.AdminDashboard.Model;
using GameStreaks.Application.AdminDashboard.Query;
using GameStreaks.Application.GameRequest.Query;
using GameStreaks.Application.Infrastructure.Dashboard;
using GameStreaks.Application.Login.Command;
using GameStreaks.Application.Profile.Command;
using GameStreaks.Application.Profile.Query;
using GameStreaks.Application.SignUp.Command;
using GameStreaks.Common;
using MediatR;
using MediatR.Pipeline;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;


namespace GameStreaks.Application.Infrastructure
{
   public class NativeInjectorBootStrapper
    {
        public static void RegisterServices(IServiceCollection services)
        {
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(RequestPreProcessorBehavior<,>));
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(RequestPerformanceBehaviour<,>));
            services.AddTransient<IDashboardService, DashboardService>();
            services.AddTransient<IEmailService, EmailService>();
            services.AddTransient<IMessageSender, EmailMessageSender>();
            #region Login/Signup
            services.AddMediatR(typeof(LoginCommand).GetTypeInfo().Assembly);
            services.AddMediatR(typeof(SignUp.Command.SignUp).GetTypeInfo().Assembly);
            services.AddMediatR(typeof(ResetPassword).GetTypeInfo().Assembly);

            services.AddMediatR(typeof(ProfileInfoCommand).GetTypeInfo().Assembly);

            #endregion
            services.AddMediatR(typeof(AdminChartData).GetTypeInfo().Assembly);
            services.AddMediatR(typeof(DashboardCartdata).GetTypeInfo().Assembly);

            services.AddMediatR(typeof(GetGameRequest).GetTypeInfo().Assembly);


        }

    }
}
