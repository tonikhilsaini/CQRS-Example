﻿using GameStreaks.Application.Login.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.Infrastructure
{

    public class RequestData
    {
        public string CustomerCreated { get; set; }
        public bool IsLoginSuccess { get; set; }
        public int TotalActiveUser { get; set; }
        public int TotalRequest { get; set; }
        public int TotalLeague { get; set; }
        public int TotalUser { get; set; }
        public object ResponseData { get; set; }
        public LoginResponseModel LoginResponseModel { get; set; } = new LoginResponseModel();
    }
    public class ApiResponse
    {
        public ApiResponse()
        {

        }
        public string Message { get; set; }
        public int StatusCode { get; set; }
        public RequestData Data { get; set; } = new RequestData();
    }
}
