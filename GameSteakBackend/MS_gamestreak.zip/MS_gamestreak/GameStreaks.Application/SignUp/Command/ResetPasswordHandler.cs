﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.SignUp.Command
{
    public class ResetPasswordHandler : IRequestHandler<ResetPassword, ApiResponse>
    {
        readonly UserManager<ApplicationUser> _userManager;
        readonly IEmailService _emailService;

        public ResetPasswordHandler(UserManager<ApplicationUser> userManager, IEmailService _emailService)
        {
            this._userManager = userManager;
            this._emailService = _emailService;
        }
        #region Reset Password
        /// <summary>
        /// To Reset Password Using Token Send To Email
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ApiResponse> Handle(ResetPassword request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                var isExist = await _userManager.FindByEmailAsync(request.Email);
                if (isExist != null)
                {
                    var isUpdated = await _userManager.ResetPasswordAsync(isExist, request.Token, request.NewPassword);
                    if (isUpdated.Succeeded)
                    {
                        response.Message = GameStreaksConstants.PASSWORD_RESET;
                        response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                    }
                    else
                    {
                        response.Message = GameStreaksConstants.ERROR_TRY_AGAIN;
                        response.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
                    }
                }
                else
                {
                    response.Message = GameStreaksConstants.EMAILDOESNOTEXIST;
                    response.StatusCode = HTTPStatusCode.BADREQUEST;
                }
            }
            catch (Exception)
            {
                response.Message = GameStreaksConstants.ERROR;
                response.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
            }
            return response;
        }
        #endregion
    }
}
