﻿using AutoMapper;
using AutoMapper.Configuration;
using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Domain.Entities;
using GameStreaks.Persistence;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;

namespace GameStreaks.Application.SignUp.Command
{
   public class SignUpHandler : IRequestHandler<SignUp, ApiResponse>
    {
        readonly GameStreaksContext _dbContext;
        readonly UserManager<ApplicationUser> _userManager;
        readonly IConfigurationRoot _configuration;
        readonly RoleManager<IdentityRole> _roleManager;
        readonly IEmailService _emailService;
        public SignUpHandler(GameStreaksContext dbContext, UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> _rolemanger, IConfigurationRoot _config, IEmailService _emailService) { 
            this._dbContext = dbContext;
            this._roleManager = _rolemanger;
            this._userManager = userManager;
            this._configuration = _config;
            this._emailService = _emailService;
        }
        #region User Registration
        /// <summary>
        /// To Register User In DB
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ApiResponse> Handle(SignUp request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            { 
                var applicationUser = await _userManager.FindByEmailAsync(request.Email);
                if (applicationUser != null)
                {
                    response.Message = GameStreaksConstants.EMAILEXISTINDB;
                    response.StatusCode = HTTPStatusCode.ERRORSTATUSCODE;
                }
                else
                {
                    User user = new User();
                    user.FirstName = request.FirstName;
                    user.LastName = request.LastName;
                    user.Email = request.Email;
                    user.CreatedDate = DateTime.UtcNow;

                        #region User signup in Identity and User table
                        var userdetail = new ApplicationUser
                        {
                            UserName = request.Email,
                            Email = request.Email,
                            FirstName = request.FirstName,
                            LastName = request.LastName,
                            EmailConfirmed = false
                        };
                        var result = await _userManager.CreateAsync(userdetail, request.Password);
                        if (result.Succeeded)
                        {
                            user.AspNetUserId = userdetail.Id;
                            user.UserName = request.UserName;
                            user.PhoneNumber = userdetail.PhoneNumber;
                            user.UserId= Convert.ToString(Guid.NewGuid());
                            user.IsActive = true;
                            user.IsDeleted = false;
                            user.CreatedDate = DateTime.UtcNow;
                            user.UserGameId = Convert.ToString(request.GameUserId);
                            await _dbContext.tbl_User.AddAsync(user);
                            await _dbContext.SaveChangesAsync();
                        

                        await _roleManager.CreateAsync(new IdentityRole(GameStreakRoles.ENDUSER));
                        IdentityRole role = await _roleManager.Roles.FirstOrDefaultAsync(x => x.Name == GameStreakRoles.ENDUSER);
                            await _userManager.AddToRoleAsync(userdetail, role.Name);
                            await _dbContext.SaveChangesAsync();

                        #endregion

                        #region Sending signup confirmation mail
                        var attempts = 0;
                        do
                        {
                            try
                            {
                                attempts++;
                                var token = await _userManager.GenerateEmailConfirmationTokenAsync(userdetail);
                                token = System.Web.HttpUtility.UrlEncode(token);
                                string url = _configuration.GetSection(AppSettings.ACCOUNTCONFIMATIONMAIL).Value;
                                string AcivationLink = url + "?eid=" + userdetail.Email + "&tkn=" + token;
                                string path = System.IO.Path.Combine(Environment.CurrentDirectory + AppSettings.CONFIMATIONMAILTEMPLATE);
                                string headerLogo = _configuration.GetSection(AppSettings.LOGGINGBASELOGO).Value;
                                path = string.Empty;
                                path = System.IO.Path.Combine(Environment.CurrentDirectory + AppSettings.ENDUSEREMAILCONFIRMATIONTEMPLATE);
                                string emailBody = File.ReadAllText(path);
                                emailBody = emailBody.Replace(AppSettings.HEADERLOGO, AppSettings.HEADERLOGOPATH);
                                emailBody = emailBody.Replace(AppSettings.HEADER_BACKGROUND_COLOR, AppSettings.HEADERBACKGROUNDCOLOR);
                                emailBody = emailBody.Replace(AppSettings.FOOTER_BACKGROUND_COLOR, AppSettings.FOOTERBACKROUNDCOLOR);
                                emailBody = emailBody.Replace(AppSettings.VERIFICATIONLINK, AcivationLink);
                                _emailService.SendRegistrationConfirmationMail(userdetail.Email, emailBody);
                                break; // Success! Lets exit the loop!
                            }
                            catch (Exception e)
                            {
                                if (attempts == 3)
                                {
                                    throw;
                                }
                                Task.Delay(5000).Wait();
                            }
                        } while (true);
                        #endregion
                    }
                        response.Message = GameStreaksConstants.CONFIRMEMAILSENT;
                        response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
            }
            catch (Exception ex)
            {
                response.Message = ex.Message;
                response.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
            }
            return response;
        }
        #endregion
    }
}
