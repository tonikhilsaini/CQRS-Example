﻿using AutoMapper.Configuration;
using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.SignUp.Command
{
    public class ForgotPasswordHandler : IRequestHandler<ForgotPassword, ApiResponse>
    {
        readonly GameStreaksContext _dbContext;
        readonly UserManager<ApplicationUser> _userManager;
        readonly RoleManager<IdentityRole> _roleManager;
        readonly IConfigurationRoot _configuration;
        readonly IEmailService _emailService;

        public ForgotPasswordHandler(GameStreaksContext dbContext, UserManager<ApplicationUser> userManager,
            IConfigurationRoot _config, RoleManager<IdentityRole> rolemanger, IEmailService emailService)
        {
           _dbContext = dbContext;
            _userManager = userManager;
            _configuration = _config;
            _roleManager = rolemanger;
           _emailService = emailService;
        }
        #region Forgot Password
        /// <summary>
        /// To Sending Email Again To Reset Password If Email Exists
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ApiResponse> Handle(ForgotPassword request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            if (string.IsNullOrEmpty(request.ForgetPasswordEmailId) && string.IsNullOrWhiteSpace(request.ForgetPasswordEmailId))
            {
                response.Message = GameStreaksConstants.EMAILIDREQUIRED;
                response.StatusCode = HTTPStatusCode.BADREQUEST;
                return response;
            }
            try
            {
                var isExist = await _userManager.FindByEmailAsync(request.ForgetPasswordEmailId);
                if (isExist != null)
                {
                    string url = _configuration.GetSection(AppSettings.RESETPASSWORD).Value;
                    string token = await _userManager.GeneratePasswordResetTokenAsync(isExist);
                    token = System.Web.HttpUtility.UrlEncode(token);
                    string AcivationLink = url + "?eid=" + request.ForgetPasswordEmailId + "&tkn=" + token;
                    string emailTemplatePath = System.IO.Path.Combine(Environment.CurrentDirectory + AppSettings.FORGOTEMAILTEMPLATE);
                    string emailBody = File.ReadAllText(emailTemplatePath);
                    #region code for end user email template
                    var userDetail = _dbContext.tbl_User.FirstOrDefault(x => x.Email == request.ForgetPasswordEmailId);
                    if (userDetail.UserGameId != null)
                    {
                        var _userdet = _dbContext.tbl_User.FirstOrDefault(x => x.UserGameId == userDetail.UserGameId);
                        if (_userdet != null)
                        {
                            emailBody = string.Empty;
                            emailTemplatePath = string.Empty;
                            emailTemplatePath = System.IO.Path.Combine(Environment.CurrentDirectory + AppSettings.ENDUSERFORGOTEMAILTEMPLATE);
                            emailBody = File.ReadAllText(emailTemplatePath);
                            emailBody = emailBody.Replace(AppSettings.GAMESTREAKSNAME, AppSettings.APPNAME);
                        }
                    }
                    #endregion
                    emailBody = emailBody.Replace(AppSettings.VERIFICATIONLINK, AcivationLink);
                    _emailService.SendPasswordResetMessage(request.ForgetPasswordEmailId, emailBody);
                    response.Message = GameStreaksConstants.RECOVERYEMAILSENT;
                    response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
                else
                {
                    response.Message = GameStreaksConstants.EMAILDOESNOTEXIST;
                    response.StatusCode = HTTPStatusCode.BADREQUEST;
                }
            }
            catch (Exception ex)
            {
                response.Message = GameStreaksConstants.ERROR;
                response.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
            }
            return response;
        }
        #endregion
    }
}
