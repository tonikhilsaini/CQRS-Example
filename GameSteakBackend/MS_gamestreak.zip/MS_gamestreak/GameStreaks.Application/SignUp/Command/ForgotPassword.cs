﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.SignUp.Command
{
  public class ForgotPassword : IRequest<ApiResponse>
    {
        public string ForgetPasswordEmailId { get; set; }
    }
}
