﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Application.SignUp.Model;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.SignUp.Command
{
   public class ConfirmEmailHandler : IRequestHandler<ConfirmEmail, ApiResponse>
    {
        readonly GameStreaksContext _dbContext;
        readonly UserManager<ApplicationUser> _userManager;
        readonly RoleManager<IdentityRole> _roleManager;
        readonly IConfigurationRoot _configuration;
        readonly IEmailService _emailService;

        public ConfirmEmailHandler(GameStreaksContext dbContext, UserManager<ApplicationUser> userManager,IConfigurationRoot _config, RoleManager<IdentityRole> _rolemanger, IEmailService _emailService)
        {
            this._dbContext = dbContext;
            this._userManager = userManager;
            this._configuration = _config;
            this._roleManager = _rolemanger;
            this._emailService = _emailService;
        }

        #region Confirm Email
        /// <summary>
        /// Confirming The Email Of User With Token
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ApiResponse> Handle(ConfirmEmail request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            if (string.IsNullOrEmpty(request.Email) || string.IsNullOrWhiteSpace(request.Email))
            {
                response.Message = GameStreaksConstants.EMAILIDREQUIRED;
                response.StatusCode = HTTPStatusCode.BADREQUEST;
                return response;
            }
            try
            {
                var userDetail = await _userManager.FindByEmailAsync(request.Email);
                var token = await _userManager.GenerateEmailConfirmationTokenAsync(userDetail);
                if (userDetail != null)
                {
                    if (!userDetail.EmailConfirmed)
                    {
                        var result = await _userManager.ConfirmEmailAsync(userDetail, request.Token);
                        // If email not confirmed.
                        if (!result.Succeeded) 
                        {
                            response.Message = (result.Errors.Select(error => error.Description).Aggregate((allErrors, error) => allErrors += ", " + error));
                            response.StatusCode = HTTPStatusCode.NO_DATA_FOUND;
                        }
                        else
                        {
                            userDetail.EmailConfirmed = true;
                            await _userManager.UpdateAsync(userDetail);
                            string url = _configuration.GetSection(AppSettings.DEFAULCORSPOLICY).Value;
                            string emailTemplatePath = System.IO.Path.Combine(Environment.CurrentDirectory + AppSettings.EMAILCONFIRMSUCCESS);
                            string emailBody = File.ReadAllText(emailTemplatePath);

                            string headerLogo = _configuration.GetSection(AppSettings.LOGGINGBASELOGO).Value;
                            #region code for end user email template
                            var userDet = _dbContext.tbl_User.FirstOrDefault(x => x.Email == userDetail.Email);
                            // When end user
                            if (userDet.UserId != null && userDet.Id > 0)
                            {
                                var storedet = _dbContext.tbl_User.FirstOrDefault(x => x.UserId == userDet.UserId);
                                if (storedet != null)
                                {
                                    emailBody = string.Empty;
                                    emailTemplatePath = string.Empty;
                                    emailTemplatePath = System.IO.Path.Combine(Environment.CurrentDirectory + AppSettings.EMAILCONFIRMSUCCESS);
                                    emailBody = File.ReadAllText(emailTemplatePath);
                                }
                            }
                            emailBody = emailBody.Replace(AppSettings.HEADERLOGO, headerLogo);
                            emailBody = emailBody.Replace(AppSettings.HEADER_BACKGROUND_COLOR, AppSettings.HEADERBACKGROUNDCOLOR);
                            emailBody = emailBody.Replace(AppSettings.FOOTER_BACKGROUND_COLOR, AppSettings.FOOTERBACKROUNDCOLOR);
                            #endregion
                            _emailService.SendConfirmationMessage(request.Email, emailBody);
                            response.Message = GameStreaksConstants.CONFIRMEMAIL_SUCCESS;
                            response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                        }
                    }
                    else
                    {
                        response.Message = GameStreaksConstants.EMAIL_ALREADY_CONFIRMED;
                        response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                    }
                }
                else
                {
                    response.Message = GameStreaksConstants.EMAILDOESNOTEXIST;
                    response.StatusCode = HTTPStatusCode.BADREQUEST;
                }
            }
            catch (Exception)
            {
                response.Message = GameStreaksConstants.ERROR;
                response.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
            }
            return response;
        }
        #endregion
    }
}
