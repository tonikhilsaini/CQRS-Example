﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.SignUp.Command
{
   public class ResendEmail :IRequest<ApiResponse>
    {
        public string EmailId { get; set; }
    }
}
