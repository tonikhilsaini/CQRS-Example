﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace GameStreaks.Application.SignUp.Command
{
   public class SignUp : IRequest<ApiResponse>
    {

        [Required]
        public string Email { get; set; }
        public Guid UserId { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        public string UserName { get; set; }
        public string ContactNo { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public long? GameUserId { get; set; }

    }
}
