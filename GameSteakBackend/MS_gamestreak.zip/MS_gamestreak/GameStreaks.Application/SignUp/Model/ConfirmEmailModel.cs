﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.SignUp.Model
{
   public class ConfirmEmailModel
    {
    }
}
