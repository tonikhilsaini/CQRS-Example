﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.UploadVideos.Command
{
   public class UploadVideo :IRequest<ApiResponse>
    {
        public string fileName { get; set; }
        public IFormFile file { get; set; }
    }
}
