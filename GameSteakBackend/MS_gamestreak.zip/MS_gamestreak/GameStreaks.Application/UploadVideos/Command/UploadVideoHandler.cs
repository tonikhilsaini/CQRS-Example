﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.UploadVideos.Command
{
    public class UploadVideoHandler : IRequestHandler<UploadVideo, ApiResponse>
    {
        readonly IConfigurationRoot _configuration;
        public UploadVideoHandler( IConfigurationRoot configuration)
        {
            _configuration = configuration;
        }
        #region Upload Video
        /// <summary>
        /// To Upload Video From Admin
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ApiResponse> Handle(UploadVideo request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            var file = request.file;
            if (file != null)
            {
                try
                {
                    string webRootPath = AppSettings.videoRoot;
                    string newPath = Path.Combine(Directory.GetCurrentDirectory(), webRootPath, file.FileName);
                    using (var stream = new FileStream(newPath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }
                    response.Message = GameStreaksConstants.VIDEOUPLOADSUCCESS;
                    response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
                catch
                {
                    response.Message = GameStreaksConstants.VIDEONOTUPLOADED;
                    response.StatusCode = HTTPStatusCode.BADREQUEST;
                }
            }
            else
            {
                response.Message = GameStreaksConstants.VIDEOCANNOTEMPTY;
                response.StatusCode = HTTPStatusCode.BADREQUEST;
            }
            return response;
        }
        #endregion
    }
}
