﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Domain.Entities;
using GameStreaks.Persistence;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.Login.Command
{
    public class LoginCommandHandler : IRequestHandler<LoginCommand, ApiResponse>
    {
        readonly SignInManager<ApplicationUser> _signInManager;
        readonly GameStreaksContext _dbContext;
        readonly UserManager<ApplicationUser> _userManager;
        readonly IConfigurationRoot _configuration;
        public LoginCommandHandler(GameStreaksContext dbContext, UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager, IConfigurationRoot _config) //
        {
            _signInManager = signInManager;
            this._dbContext = dbContext;
            this._userManager = userManager;
            this._configuration = _config;
        }
        #region Login
        /// <summary>
        /// Loging In User After Credentials Check
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ApiResponse> Handle(LoginCommand request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                var users = await _userManager.FindByEmailAsync(request.Email);
                if (users == null)
                {
                    response.Message = GameStreaksConstants.EMAILDOESNOTEXIST + " " + GameStreaksConstants.REGISTEREMAIL;
                    response.StatusCode = HTTPStatusCode.NO_DATA_FOUND;
                    return response;
                }
                var result = await _signInManager.PasswordSignInAsync(request.Email, request.Password, request.RememberMe, lockoutOnFailure: false);
                if (result.Succeeded)
                {
                    var UserDetail = _dbContext.tbl_User.FirstOrDefault(x => x.Email == request.Email);
                    var user = await _userManager.FindByEmailAsync(request.Email);
                    if (user.EmailConfirmed)
                    {
                        //Creating Token For User
                        var userClaims = await _userManager.GetClaimsAsync(user);
                        var roles = _userManager.GetRolesAsync(user);
                        userClaims.Add(new Claim(JwtRegisteredClaimNames.Sub, user.UserName));
                        userClaims.Add(new Claim(JwtRegisteredClaimNames.Email, user.Email));
                        userClaims.Add(new Claim(ClaimTypes.Role, roles.Result[0]));
                        userClaims.Add(new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()));
                        string k = _configuration[AppSettings.JWTKEY];
                        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(k));
                        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                        var token = new JwtSecurityToken(
                          issuer: _configuration.GetSection(AppSettings.JWTISSUEROPTION).Value,
                          audience: _configuration.GetSection(AppSettings.JWTISSUERAUDENCE).Value,
                          claims: userClaims,
                          expires: DateTime.Now.AddMinutes(60),
                          signingCredentials: creds
                        );
                        //Creating Token For User

                        //Set Active Status To True
                        User userActive = _dbContext.tbl_User.Where(x => x.UserId == UserDetail.UserId).FirstOrDefault();
                        userActive.IsActive = true;
                        _dbContext.Update(userActive);
                        await _dbContext.SaveChangesAsync();
                        //Set Active Status To True

                        response.Data.LoginResponseModel.ProfileImage = UserDetail.ProfileImage;
                        response.Data.LoginResponseModel.FullName = UserDetail.FirstName + " " + UserDetail.LastName;
                        response.Data.LoginResponseModel.UserId = Guid.Parse(UserDetail.UserId);
                        response.Data.LoginResponseModel.Email = UserDetail.Email;
                        response.Data.LoginResponseModel.GameId = UserDetail.UserGameId;
                        response.Data.LoginResponseModel.Role = roles.Result[0];
                        response.Data.LoginResponseModel.Token = new JwtSecurityTokenHandler().WriteToken(token);
                        response.Message = GameStreaksConstants.LOGGEDIN;
                        response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                    }
                    else
                    {
                        response.Message = GameStreaksConstants.EMAIL_NOTCONFIRMED;
                        response.StatusCode = HTTPStatusCode.BADREQUEST;
                    }
                }
                else
                {
                    response.Message = GameStreaksConstants.INVALIDCREDENTIALS;
                    response.StatusCode = HTTPStatusCode.BADREQUEST;
                }
            }
            catch (Exception ex)
            {
                response.Message = ex.Message;
                response.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
            }
            return response;
        }
        #endregion
    }
}
