﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.League.Command
{
    public partial class AddLeagueType : IRequest<ApiResponse>
    {
        public string Name { get; set; }
    }
}
