﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Domain.Entities;
using GameStreaks.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.League.Command
{
    public class AddLeagueFormatHandler : IRequestHandler<AddLeagueFormat, ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public AddLeagueFormatHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<ApiResponse> Handle(AddLeagueFormat request, CancellationToken cancellationToken)
        {
            ApiResponse apiResponse = new ApiResponse();
            try
            {
                var leagueType = new LeagueFormat
                {
                    Name = request.Name
                };
                _dbContext.Add(leagueType);
                await _dbContext.SaveChangesAsync();
                apiResponse.Message = GameStreaksConstants.ADDLEAGUEFORMAT;
                apiResponse.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;

            }
            catch (Exception e)
            {
                apiResponse.Message = GameStreaksConstants.ERROR;
                apiResponse.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
            }
            return apiResponse;
        }
    }
}
