﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Domain.Entities;
using GameStreaks.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.League.Command
{
    class AddLeagueTypeHandler : IRequestHandler<AddLeagueType, ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public AddLeagueTypeHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<ApiResponse> Handle(AddLeagueType request, CancellationToken cancellationToken)
        {
            ApiResponse apiResponse = new ApiResponse();
            try
            {
                var leagueType = new LeagueType
                {
                    Name=request.Name
                };
                _dbContext.Add(leagueType);
                await _dbContext.SaveChangesAsync();
                apiResponse.Message = GameStreaksConstants.ADDEDLEAGUETYPE;
                apiResponse.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;

            }
            catch (Exception e)
            {
                apiResponse.Message = GameStreaksConstants.ERROR;
                apiResponse.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
            }
            return apiResponse;
        }
    }
}
