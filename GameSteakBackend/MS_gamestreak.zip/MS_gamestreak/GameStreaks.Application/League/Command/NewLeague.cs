﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.League.Command
{
    public class NewLeague : IRequest<ApiResponse>
    {
        public string LeagueName { get; set; }
        public Guid LeagueTypeId { get; set; }
        public Guid LeagueFormatId { get; set; }
        public string StartWeek { get; set; }
        public Guid GameType { get; set; }
        public string EntryFee { get; set; }
        public string CurrentEntrants { get; set; }
        public string MaxEntrants { get; set; }
        public string Prize { get; set; }

        public DateTime StartDateTime { get; set; }
        public DateTime EndDateTime { get; set; }
    }
}
