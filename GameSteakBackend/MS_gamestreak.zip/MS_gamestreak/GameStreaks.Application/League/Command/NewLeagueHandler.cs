﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.League.Command
{
    public class NewLeagueHandler : IRequestHandler<NewLeague, ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public NewLeagueHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<ApiResponse> Handle(NewLeague request, CancellationToken cancellationToken)
        {
            ApiResponse apiResponse = new ApiResponse();
            try
            {
                var newLeague = new GameStreaks.Domain.Entities.League
                {
                    LeagueName = request.LeagueName,
                    LeagueTypeId=request.LeagueTypeId,
                    LeagueFormatId=request.LeagueFormatId,
                    StartWeek=request.StartWeek,
                    GameType=request.GameType,
                    EntryFee=request.EntryFee,
                    CurrentEntrants=request.CurrentEntrants,
                    MaxEntrants=request.MaxEntrants,
                    Prize=request.Prize,
                    StartDateTime=request.StartDateTime,
                    EndDateTime=request.EndDateTime,
                    IsActive=true,
                    CreatedDate=DateTime.UtcNow
                };
                _dbContext.Add(newLeague);
                await _dbContext.SaveChangesAsync();
                apiResponse.Message = GameStreaksConstants.ADDNEWLEAGUE;
                apiResponse.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;

            }
            catch (Exception e)
            {
                apiResponse.Message = GameStreaksConstants.ERROR;
                apiResponse.StatusCode = HTTPStatusCode.INTERNAL_SERVER_ERROR;
            }
            return apiResponse;
        }
    }
}