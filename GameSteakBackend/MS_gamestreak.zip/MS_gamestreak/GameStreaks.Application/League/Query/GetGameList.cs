﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;


namespace GameStreaks.Application.League.Query
{
    public partial class GetGameList : IRequest<ApiResponse>
    {
        public string GameId { get; set; }
        public string GameName { get; set; }
    }
}
