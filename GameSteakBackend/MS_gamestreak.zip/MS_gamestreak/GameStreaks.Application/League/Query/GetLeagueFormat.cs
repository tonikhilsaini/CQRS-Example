﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.League.Query
{
    public class GetLeagueFormat : IRequest<ApiResponse>
    {
        public string LeagueFormatId { get; set; }
        public string LeagueFormatName { get; set; }
    }
}