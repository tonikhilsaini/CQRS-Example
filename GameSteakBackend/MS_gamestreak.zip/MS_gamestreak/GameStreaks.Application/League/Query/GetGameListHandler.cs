﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.League.Query
{
    class GetGameListHandler : IRequestHandler<GetGameList, ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public GetGameListHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<ApiResponse> Handle(GetGameList request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                var gameDetails = _dbContext.tbl_GameType.Select(x => new GetGameList
                {
                    GameId = x.GameTypeId.ToString(),
                    GameName = x.GameType,
                });
                if (gameDetails != null)
                {
                    response.Data.ResponseData = gameDetails;
                    response.Message = GameStreaksConstants.GAMELIST;
                    response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
                else
                {
                    response.Message = GameStreaksConstants.NO_RECORD;
                    response.StatusCode = HTTPStatusCode.NO_DATA_FOUND;
                }
            }
            catch (Exception ex)
            {
                response.Message = GameStreaksConstants.NO_RECORD;
                response.StatusCode = HTTPStatusCode.NO_DATA_FOUND;
            }
            return response;
        }
    }
}
