﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.League.Query
{
    public class GetLeagueFormatHandler : IRequestHandler<GetLeagueFormat, ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public GetLeagueFormatHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<ApiResponse> Handle(GetLeagueFormat request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                var gameDetails = _dbContext.tbl_LeagueFormat.Select(x => new GetLeagueFormat
                {
                    LeagueFormatId=x.Id.ToString(),
                    LeagueFormatName=x.Name
                });
                if (gameDetails != null)
                {
                    response.Data.ResponseData = gameDetails;
                    response.Message = GameStreaksConstants.LEAGUEFORMATLIST;
                    response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
                else
                {
                    response.Message = GameStreaksConstants.NO_RECORD;
                    response.StatusCode = HTTPStatusCode.NO_DATA_FOUND;
                }
            }
            catch (Exception ex)
            {
                response.Message = GameStreaksConstants.NO_RECORD;
                response.StatusCode = HTTPStatusCode.NO_DATA_FOUND;
            }
            return response;
        }
    }
}