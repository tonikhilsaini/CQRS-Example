﻿using GameStreaks.Application.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameStreaks.Application.League.Query
{
   public class GetLeagueTypeList  : IRequest<ApiResponse>
    {
        public string LeagueId { get; set; }
        public string LeagueTypeName { get; set; }
    }
}
