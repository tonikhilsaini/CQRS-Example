﻿using GameStreaks.Application.Infrastructure;
using GameStreaks.Common;
using GameStreaks.Persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GameStreaks.Application.League.Query
{
    public class GetLeagueTypeListHandler : IRequestHandler<GetLeagueTypeList, ApiResponse>
    {
        private readonly GameStreaksContext _dbContext;
        public GetLeagueTypeListHandler(GameStreaksContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<ApiResponse> Handle(GetLeagueTypeList request, CancellationToken cancellationToken)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                var leagueTypeDetails = _dbContext.tbl_LeagueType.Select(x => new GetLeagueTypeList
                {
                    LeagueId = x.Id.ToString(),
                    LeagueTypeName = x.Name,
                });
                if (leagueTypeDetails != null)
                {
                    response.Data.ResponseData = leagueTypeDetails;
                    response.Message = GameStreaksConstants.LEAGUETYPELIST;
                    response.StatusCode = HTTPStatusCode.SUCCESSSTATUSCODE;
                }
                else
                {
                    response.Message = GameStreaksConstants.NO_RECORD;
                    response.StatusCode = HTTPStatusCode.NO_DATA_FOUND;
                }
            }
            catch (Exception ex)
            {
                response.Message = GameStreaksConstants.NO_RECORD;
                response.StatusCode = HTTPStatusCode.NO_DATA_FOUND;
            }
            return response;
        }
    }
}
