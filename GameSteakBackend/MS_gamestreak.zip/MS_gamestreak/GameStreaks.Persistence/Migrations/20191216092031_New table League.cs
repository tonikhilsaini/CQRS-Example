﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace GameStreaks.Persistence.Migrations
{
    public partial class NewtableLeague : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tbl_League",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    ModifiedDate = table.Column<DateTime>(nullable: true),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    DeletedDate = table.Column<DateTime>(nullable: true),
                    LeagueName = table.Column<string>(nullable: false),
                    LeagueTypeId = table.Column<Guid>(nullable: false),
                    LeagueFormatId = table.Column<Guid>(nullable: false),
                    StartWeek = table.Column<string>(nullable: false),
                    GameType = table.Column<Guid>(nullable: false),
                    EntryFee = table.Column<string>(nullable: false),
                    CurrentEntrants = table.Column<string>(nullable: false),
                    MaxEntrants = table.Column<string>(nullable: false),
                    Prize = table.Column<string>(nullable: false),
                    StartDateTime = table.Column<DateTime>(nullable: false),
                    EndDateTime = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_League", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tbl_League");
        }
    }
}
