﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace GameStreaks.Persistence.Migrations
{
    public partial class newtableleagueformat : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tbl_LeagueFormat",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_LeagueFormat", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tbl_LeagueFormat");
        }
    }
}
