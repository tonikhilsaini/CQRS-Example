﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using Microsoft.AspNetCore.Identity;
using GameStreaks.Persistence.Extensions;
using GameStreaks.Domain.Entities;

namespace GameStreaks.Persistence
{
    public class GameStreaksContext : IdentityDbContext<ApplicationUser>
    {

        public GameStreaksContext(DbContextOptions<GameStreaksContext> options) : base(options)
        {
        }
        public DbSet<User> tbl_User { get; set; }
     //   public DbSet<Address> tbl_Addresses { get; set; } 
        public DbSet<GameLobby> tbl_GameLobby { get; set; }
        public DbSet<GameTypes> tbl_GameType { get; set; }
        public DbSet<GameRequest> tbl_GameRequest { get; set; }
        public DbSet<LeagueType> tbl_LeagueType { get; set; }
        public DbSet<LeagueFormat> tbl_LeagueFormat { get; set; }
        public DbSet<League> tbl_League { get; set; }
        public DbSet<ConfidenceGame> tbl_ConfidenceGame { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyAllConfigurations();
            base.OnModelCreating(modelBuilder);
        }
    }
}
