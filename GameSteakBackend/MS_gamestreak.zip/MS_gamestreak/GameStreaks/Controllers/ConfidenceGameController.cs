﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GameStreaks.Application.ConfidenceGame.Command;
using GameStreaks.Application.ConfidenceGame.Query;
using GameStreaks.Application.Infrastructure;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace GameStreaks.Controllers
{
    [Route("ConfidenceGame")]
    [ApiController]
    public class ConfidenceGameController : ControllerBase
    {
        private readonly IMediator _mediator;
        public ConfidenceGameController(IMediator mediator)
        {
            this._mediator = mediator;
        }
        /// <summary>
        /// API To get league list
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetLeague")]
        //[Authorize(Policy = "EndUser")]
        public async Task<ApiResponse> GetLeague()
        {
            return await _mediator.Send(new GetLeague());
        }

        /// <summary>
        /// API to create new confidence game
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("CreateConfidenceGame")]
        //[Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> CreateFormat(CreateConfidenceGame command)
        {
            return await _mediator.Send(command);
        }

        [HttpGet]
        [Route("GetConfidenceGame")]
        //[Authorize(Policy = "EndUser")]
        public async Task<ApiResponse> GetConfidenceGame()
        {
            return await _mediator.Send(new GetConfidenceGame());
        }

        [HttpGet]
        [Route("EditConfidenceGame")]
        //[Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> EditConfidenceGame(string confidenceGameId)
        {
            return await _mediator.Send(new EditConfidenceGame { ConfidenceGameID = confidenceGameId });
        }

        [HttpGet]
        [Route("DeleteConfidenceGame")]
        //[Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> DeleteConfidenceGame(string confidenceGameId)
        {
            return await _mediator.Send(new DeleteConfidenceGame { ConfidenceGameID = confidenceGameId });
        }

        [HttpGet]
        [Route("PickConfidenceGame")]
        //[Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> PickConfidenceGame(string LeagueId)
        {
            return await _mediator.Send(new PickConfidenceGame { LeagueId = LeagueId });
        }
    }
}