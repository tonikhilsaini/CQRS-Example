﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GameStreaks.Application.AddGame.Command;
using GameStreaks.Application.AddGame.Query;
using GameStreaks.Application.GameLobbys.Command;
using GameStreaks.Application.GameRequest.Command;
using GameStreaks.Application.GameRequest.Query;
using GameStreaks.Application.Infrastructure;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GameStreaks.Controllers
{
    [Route("Game")]
    [ApiController]
    public class GameController : ControllerBase
    {
        private readonly IMediator _mediator;
        public GameController(IMediator mediator)
        {
            this._mediator = mediator;
        }
        #region Create Game

        [HttpPost]
        [Route("CreateGame")]
        [Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> CreateGame(CreateGame command)
        {
            return await _mediator.Send(command);

        }
        #endregion

        #region Create Game Type

        [HttpPost]
        [Route("CreateGameType")]
        [Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> CreateGameType(AddGameTypes command)
        {
            return await _mediator.Send(command);

        }
        #endregion


        [HttpGet]
        [Route("GameLobby")]
        //[Authorize(Policy = "EndUser")]
        public async Task<ApiResponse> GameLobby()
        {
            return await _mediator.Send(new GetGameLobby());
        }

        /// <summary>
        /// API to create new request send for the game or league
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("SendRequest")]
        public async Task<ApiResponse> SendRequest(GameRequests command)
        {
            return  await _mediator.Send(command);
        }

      


    }
}