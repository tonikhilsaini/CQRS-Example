﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GameStreaks.Application.Infrastructure;
using GameStreaks.Application.Login.Command;
using GameStreaks.Application.Logout.Command;
using GameStreaks.Application.Profile.Command;
using GameStreaks.Application.Profile.Query;
using GameStreaks.Application.SignUp.Command;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GameStreaks.Controllers
{
    [Route("Account")]
    [ApiController]
    public class AccountController : ControllerBase
    {

        private readonly IMediator _mediator;
        public AccountController(IMediator mediator)
        {
            _mediator = mediator;
        }
        #region Login

        [AllowAnonymous]
        [HttpPost]
        [Route("Login")]
        public async Task<ApiResponse> Login([FromBody]LoginCommand command)
        {
            return await _mediator.Send(command);
        }
        #endregion

        #region Register
        
        [AllowAnonymous]
        [HttpPost]
        [Route("SignUp")]
        public async Task<ApiResponse> Signup([FromBody]SignUp command)
        {
            return await _mediator.Send(command);
        }
        #endregion

        #region Confirm Email
        
        [AllowAnonymous]
        [HttpPost]
        [Route("ConfirmEmail")]
        public async Task<ApiResponse> ConfirmEmail(ConfirmEmail command)
        {
            return await _mediator.Send(command);
        }
        #endregion

        #region Forgot Paasword
        
        [AllowAnonymous]
        [HttpPost]
        [Route("ForgotPassword")]
        public async Task<ApiResponse> ForgotPassword(ForgotPassword command)
        {
            return await _mediator.Send(command);
        }
        #endregion

        #region Reset Password

        [AllowAnonymous]
        [HttpPost]
        [Route("ResetPassword")]
        public async Task<ApiResponse> ResetPassword(ResetPassword command)
        {
            return await _mediator.Send(command);
        }
        #endregion

        #region Get Profile Info

        [HttpGet]
        [Route("GetProfileInfo")]
        [Authorize(Policy = "AllRoles")]
        public async Task<ApiResponse> GetProfileInfo(string userId)
        {
            return await _mediator.Send(new GetProfileInfoQuery { UserId = userId });
        }
        #endregion

        #region Save Profile Info

        [HttpPost]
        [Route("SaveProfileInfo")]
        [Authorize(Policy = "AllRoles")]
        public async Task<ApiResponse> SaveProfileInfo([FromBody]ProfileInfoCommand command)
        {
            return await _mediator.Send(command);
        }
        #endregion

        #region Resend Email

        [AllowAnonymous]
        [HttpPost]
        [Route("ResendEmail")]
        public async Task<ApiResponse> ResendEmail(string Email)
        {
            return await _mediator.Send(new ResendEmail { EmailId = Email });
        }
        #endregion

        #region Logout

        [AllowAnonymous]
        [HttpGet]
        [Route("logout")]
        public async Task<ApiResponse> logout(string UserId)
        {
            return await _mediator.Send(new Logout { UserId = UserId });
        }
        #endregion
    }
}