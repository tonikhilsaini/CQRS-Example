﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GameStreaks.Application.Infrastructure;
using GameStreaks.Application.League.Command;
using GameStreaks.Application.League.Query;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GameStreaks.Controllers
{
    /// <summary>
    /// This is used for all league functionality
    /// </summary>
   //[Authorize(Policy = "RequireAdmin")]
    [Produces("application/json")]
    [Route("League")]
    [ApiController]
    public class LeagueController : ControllerBase
    {
        private readonly IMediator _mediator;
        public LeagueController(IMediator mediator)
        {
            _mediator = mediator;
        }


        /// <summary>
        /// API to get game type
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetGameType")]
        //[Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> GetGameType()
        {
            return await _mediator.Send(new GetGameList());
        }

        /// <summary>
        /// API to create new league type
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("CreateLeagueType")]
        //[Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> CreateLeagueType(AddLeagueType command)
        {
            return await _mediator.Send(command);
        }

        /// <summary>
        /// API to get league type
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetLeagueType")]
        //[Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> GetLeagueType()
        {
            return await _mediator.Send(new GetLeagueTypeList());
        }

        /// <summary>
        /// API to create new league format
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("CreateLeagueFormat")]
        //[Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> CreateFormat(AddLeagueFormat command)
        {
            return await _mediator.Send(command);
        }

        /// <summary>
        /// API to get list of league format
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetLeagueFormat")]
        //[Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> GetLeagueFormat()
        {
            return await _mediator.Send(new GetLeagueFormat());
        }

        /// <summary>
        /// API to create new league
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("SaveNewLeague")]
        //[Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> SaveNewLeague(NewLeague command)
        {
            return await _mediator.Send(command);
        }

    }
}