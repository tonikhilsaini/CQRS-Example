﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GameStreaks.Application.AdminData.ActiveUsersList.Query;
using GameStreaks.Application.AdminData.DeleteUser;
using GameStreaks.Application.AdminData.UsersList.Query;
using GameStreaks.Application.GameRequest.Command;
using GameStreaks.Application.GameRequest.Query;
using GameStreaks.Application.Infrastructure;
using GameStreaks.Application.UploadVideos.Command;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GameStreaks.Controllers
{
    //[Authorize(Policy = "RequireAdmin")]
    [Produces("application/json")]
    [Route("Admin")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IMediator _mediator;
        public AdminController(IMediator mediator)
        {
            _mediator = mediator;
        }

        #region Upload Videos

        [HttpPost]
        [Route("UploadVideos")]
        [Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> UploadVideos(IFormFile file)
        {
            return await _mediator.Send(new UploadVideo { file = file });
        }
        #endregion

        #region Get Users List

        [HttpGet]
        [Route("GetUsersList")]
        [Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> GetUsersList(string userId)
        {
            return await _mediator.Send(new GetUsersList { UserId = userId });
        }
        #endregion

        #region Get Active Users List

        [HttpGet]
        [Route("GetActiveUsersList")]
        [Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> GetActiveUsersList(string userId)
        {
            return await _mediator.Send(new GetActiveUsersList { UserId = userId });
        }
        #endregion

        #region Delete User

        [HttpPost]
        [Route("DeleteUser")]
        [Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> DeleteUser(string userId)
        {
            return await _mediator.Send(new DeleteUser { UserId = userId });
        }
        #endregion


        /// <summary>
        /// API to get all game requested by the user 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GameRequest")]
        //[Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> GetGameRequest()
        {
            return await _mediator.Send(new GetGameRequest());
        }

        /// <summary>
        /// API to activate game requested by user
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("ActivateGameRequest")]
        //[Authorize(Policy = "RequireAdmin")]
        [AllowAnonymous]
        public async Task<ApiResponse> ActivateGameRequest(ActivateGameRequest command)
        {
            return await _mediator.Send(command);
        }

    }
}