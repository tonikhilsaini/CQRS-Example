﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GameStreaks.Application.AdminDashboard.Query;
using GameStreaks.Application.AdminData.UsersList.Query;
using GameStreaks.Application.Infrastructure;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GameStreaks.Controllers
{
    [Route("Dashboard")]
    [ApiController]
    public class DashBoardController : ControllerBase
    {
        private readonly IMediator _mediator;
        public DashBoardController(IMediator mediator)
        {
            this._mediator = mediator;
        }

        #region Admin Dashboard Data

        [HttpGet]
        [Route("GetSuperAdminDashboardData")]
        [Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> GetSuperAdminDashboardData(string UserId)
        {
            return await _mediator.Send(new GetSuperAdminDashboardData { UserId= UserId });
        }
        #endregion

        #region Admin Pie Chart Data

        [HttpGet]
        [Route("GetAdminChartData")]
        [Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> GetAdminChartData(string UserId)
        {
            return await _mediator.Send(new AdminChartData { UserId = UserId });
        }
        #endregion

        #region Admin Bar Chart Data

        [HttpGet]
        [Route("GetAdminBarChartData")]
        [Authorize(Policy = "RequireAdmin")]
        public async Task<ApiResponse> GetAdminBarChartData(string UserId)
        {
            return await _mediator.Send(new AdminBarChartData { UserId = UserId });
        }
        #endregion

    }
}